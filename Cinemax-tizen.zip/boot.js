/* Cinémax télé Samsung : préparatifs avant le chargement de l'app (JavaScript « ancien », sans transformation). */
(function () {
  // -1. Sur la télé, la page est agrandie (1280 → 1920) : visualViewport annonce une échelle de 1,5 et
  //     React Native Web en déduisait un écran de 1920×1080 (tout était trop grand et décalé).
  //     Sans visualViewport, il lit la vraie largeur de mise en page (1280×720).
  try {
    Object.defineProperty(window, 'visualViewport', { value: undefined, configurable: true });
  } catch (e) {}

  // 0. Dossier de l'app (file:///…/index.html → file:///…/) : base des images et polices
  window.__cxBase = location.href.replace(/[?#].*$/, '').replace(/[^/]*$/, '');

  // crypto.randomUUID : absent avant Chromium 92 (télés jusqu'à 2022)
  if (window.crypto && !window.crypto.randomUUID && window.crypto.getRandomValues) {
    window.crypto.randomUUID = function () {
      var b = window.crypto.getRandomValues(new Uint8Array(16));
      b[6] = (b[6] & 15) | 64;
      b[8] = (b[8] & 63) | 128;
      var h = [];
      for (var i = 0; i < 16; i++) h.push((b[i] + 256).toString(16).slice(1));
      return h.slice(0, 4).join('') + '-' + h.slice(4, 6).join('') + '-' + h.slice(6, 8).join('') + '-' + h.slice(8, 10).join('') + '-' + h.slice(10).join('');
    };
  }

  // 1. L'app est ouverte depuis un fichier (file://) : la navigation ne peut pas changer l'adresse.
  //    On garde l'historique (état) mais sans toucher à l'URL.
  var H = window.History && History.prototype;
  if (H) {
    var ps = H.pushState;
    var rs = H.replaceState;
    var fromFile = location.protocol === 'file:';
    H.pushState = function (s, t, u) {
      if (fromFile) return ps.call(this, s, t);
      try {
        return ps.call(this, s, t, u);
      } catch (e) {
        return ps.call(this, s, t);
      }
    };
    H.replaceState = function (s, t, u) {
      if (fromFile) return rs.call(this, s, t);
      try {
        return rs.call(this, s, t, u);
      } catch (e) {
        return rs.call(this, s, t);
      }
    };
  }

  // 2. « gap » dans les flexbox : absent des télés avant 2022 (Chromium < 84). On le remplace par des marges.
  function flexGapSupported() {
    var d = document.createElement('div');
    d.style.cssText = 'display:flex;flex-direction:column;row-gap:1px;position:absolute;visibility:hidden';
    d.appendChild(document.createElement('div'));
    d.appendChild(document.createElement('div'));
    document.body.appendChild(d);
    var ok = d.scrollHeight === 1;
    document.body.removeChild(d);
    return ok;
  }

  function px(v) {
    var n = parseFloat(v);
    return isNaN(n) ? 0 : n;
  }

  function base(child, prop) {
    var key = '__cx_' + prop;
    if (child[key] === undefined) child[key] = px(getComputedStyle(child)[prop]);
    return child[key];
  }

  function setPx(el, prop, v) {
    var s = v + 'px';
    if (el.style[prop] !== s) el.style[prop] = s;
  }

  function flowChildren(el) {
    var out = [];
    for (var i = 0; i < el.children.length; i++) {
      var c = el.children[i];
      var cs = getComputedStyle(c);
      if (cs.position === 'absolute' || cs.position === 'fixed' || cs.display === 'none') continue;
      out.push(c);
    }
    return out;
  }

  // Classes CSS qui posent un « gap » (React Native Web range les styles dans des classes) :
  // on ne mesure que ces éléments-là, au lieu d'interroger le style de chaque élément de la page.
  var gapSet = {};
  var ruleCount = -1;
  function refreshGapClasses() {
    var sheets = document.styleSheets;
    var n = 0;
    var i, j, rules;
    for (i = 0; i < sheets.length; i++) {
      try { n += sheets[i].cssRules.length; } catch (e) {}
    }
    if (n === ruleCount) return;
    ruleCount = n;
    for (i = 0; i < sheets.length; i++) {
      try { rules = sheets[i].cssRules; } catch (e) { continue; }
      for (j = 0; j < rules.length; j++) {
        var r = rules[j];
        if (!r.selectorText || r.cssText.indexOf('gap') < 0) continue;
        var m = r.selectorText.match(/\.([\w-]+)/g);
        if (m) for (var k = 0; k < m.length; k++) gapSet[m[k].slice(1)] = 1;
      }
    }
  }
  function mayHaveGap(el) {
    if (el.__cxGap) return true;
    var st = el.style;
    if (st && (st.rowGap || st.columnGap || st.gap)) return true;
    var cl = el.classList;
    if (cl) for (var i = 0; i < cl.length; i++) if (gapSet[cl[i]]) return true;
    return false;
  }

  function applyGap(el) {
    if (!el || el.nodeType !== 1) return;
    if (!mayHaveGap(el)) return;
    var cs = getComputedStyle(el);
    if (cs.display !== 'flex' && cs.display !== 'inline-flex') return;
    var rg = px(cs.rowGap);
    var cg = px(cs.columnGap);
    if (!rg && !cg) return;
    el.__cxGap = true;
    var kids = flowChildren(el);
    var dir = cs.flexDirection;
    var wrap = cs.flexWrap !== 'nowrap';
    var row = dir === 'row' || dir === 'row-reverse';
    var rev = dir === 'row-reverse' || dir === 'column-reverse';
    var i;
    if (!wrap) {
      for (i = 0; i < kids.length; i++) {
        var c = kids[i];
        if (row) setPx(c, rev ? 'marginRight' : 'marginLeft', base(c, rev ? 'marginRight' : 'marginLeft') + (i > 0 ? cg : 0));
        else setPx(c, rev ? 'marginBottom' : 'marginTop', base(c, rev ? 'marginBottom' : 'marginTop') + (i > 0 ? rg : 0));
      }
      return;
    }
    if (!row) return;
    // flex-wrap en ligne : marge à gauche sauf en début de ligne, marge en haut sauf sur la première ligne
    for (i = 0; i < kids.length; i++) {
      setPx(kids[i], 'marginLeft', base(kids[i], 'marginLeft') + (i > 0 ? cg : 0));
      setPx(kids[i], 'marginTop', base(kids[i], 'marginTop'));
    }
    for (var pass = 0; pass < 3; pass++) {
      var changed = false;
      var firstTop = kids.length ? kids[0].offsetTop : 0;
      var prevTop = null;
      for (i = 0; i < kids.length; i++) {
        var k = kids[i];
        var top = k.offsetTop;
        var startsLine = i === 0 || (prevTop !== null && top > prevTop + 1);
        var ml = base(k, 'marginLeft') + (startsLine ? 0 : cg);
        var mt = base(k, 'marginTop') + (top > firstTop + 1 ? rg : 0);
        if (k.style.marginLeft !== ml + 'px' || k.style.marginTop !== mt + 'px') {
          setPx(k, 'marginLeft', ml);
          setPx(k, 'marginTop', mt);
          changed = true;
        }
        prevTop = k.offsetTop;
      }
      if (!changed) break;
    }
  }

  function scanTree(root, set) {
    if (root.nodeType !== 1) return;
    set.push(root);
    var all = root.getElementsByTagName('*');
    for (var i = 0; i < all.length; i++) set.push(all[i]);
  }

  function startGapPolyfill() {
    var queue = [];
    var scheduled = false;
    var flushId = 0;
    function flush() {
      scheduled = false;
      var list = queue;
      queue = [];
      var mark = ++flushId;
      refreshGapClasses();
      for (var i = 0; i < list.length; i++) {
        var el = list[i];
        if (el.__cxSeen === mark || !el.isConnected) continue;
        el.__cxSeen = mark;
        applyGap(el);
      }
    }
    function push(el) {
      if (el && el.nodeType === 1) queue.push(el);
      if (!scheduled) {
        scheduled = true;
        (window.requestAnimationFrame || setTimeout)(flush);
      }
    }
    new MutationObserver(function (records) {
      for (var i = 0; i < records.length; i++) {
        var r = records[i];
        if (r.type === 'childList') {
          push(r.target);
          for (var j = 0; j < r.addedNodes.length; j++) {
            var tmp = [];
            scanTree(r.addedNodes[j], tmp);
            for (var k = 0; k < tmp.length; k++) push(tmp[k]);
          }
        } else if (r.attributeName === 'class') {
          push(r.target);
          if (r.target.parentNode) push(r.target.parentNode);
        }
      }
    }).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
    window.addEventListener('resize', function () {
      var all = document.body.getElementsByTagName('*');
      for (var i = 0; i < all.length; i++) if (all[i].__cxGap) push(all[i]);
    });
  }

  function onReady() {
    if (window.__cxForceGapPolyfill || !flexGapSupported()) startGapPolyfill();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', onReady);
  else onReady();
})();
